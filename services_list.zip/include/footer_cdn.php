    <!-- Javascript  -->
    <!-- vendor js -->
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/quill/quill.js"></script>
    <script src="assets/js/pages/form-editor.init.js"></script>
    <script src="assets/js/app.js"></script>
    
</body>
<!--end body-->
</html>

