<?php 
include 'check_login.php';
include 'include/header_cdn.php'; 
?>
<?php include 'include/header.php'; ?>
<?php include 'include/menu.php'; ?>

    <div class="page-wrapper">

    </div>
    <!-- end page-wrapper -->

<?php include 'include/footer_cdn.php'; ?>

